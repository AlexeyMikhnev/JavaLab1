package Mephi_Mikhnev;

public class List {
    public Object[] data;

    public List(Object element) {
        this.data = new Object[1];
        this.data[0] = element;
    }

    public void add(Object data) {
        Object[] tmp = new Object[this.data.length + 1];
        for (int i = 0; i < this.data.length; i++)
        {
            tmp[i] = this.data[i];
        }
        tmp[this.data.length] = data;
        this.data = tmp;
    }
    public void remove(int index) {
        if ((index<0) || (index >= this.data.length))
            System.out.println("Incorrect index");
        else {
            Object[] tmp = new Object[this.data.length - 1];
            int k = 0;
            for (int i = 0; i<this.data.length; i++) {
                if (i != index) {
                    tmp[k] = this.data[i];
                    k++;
                }
            }
            this.data = tmp;
        }
    }
    public void add(Object data, int index) {
        if ((index<0) || (index >= this.data.length)) {
            System.out.println("Incorrect index");
        }
        else {
            Object[] tmp = new Object[this.data.length + 1];
            int k = 0;
            for (int i = 0; i<this.data.length; i++) {
                if (i != index) {
                    tmp[k] = this.data[i];
                    k++;
                }
                else
                {
                    tmp[k] = data;
                    k++;
                    tmp[k] = this.data[i];
                    k++;
                }
            }
            this.data = tmp;

        }
    }
    public Object get(int index) {
        if ((index<0) || (index >= this.data.length))
            System.out.println("Incorrect index");
        else
            return this.data[index];
        return 0;
    }
    public int IndexOf(Object data) {
        if (this.contains(data))
        {
            for (int i = 0; i<this.data.length; i++)
            {
                if (this.data[i]==data)
                    return i;
            }
        }
        else
            return -1;
        return 0;
    }
    public boolean contains(Object data) {
        for (int i = 0; i<this.data.length; i++)
        {
            if (this.data[i]==data)
                return true;
        }
        return false;
    }
    public void set(Object data, int index) {
        if (index > this.data.length)
            System.out.println("Incorrect index");
        else
            this.data[index] = data;
    }
    public int size() {
        if (this.data == null)
            return 0;
        else
            return this.data.length;
    }
    public boolean IsEmpty() {
        if (this.data.length == 0) return true;
        return false;
    }
}
