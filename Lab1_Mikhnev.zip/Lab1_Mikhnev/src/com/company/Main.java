package com.company;

import Mephi_Mikhnev.List;

public class Main {

    static void TestList() {
        System.out.println("Constructor Test, create list of 1 element");
        List L = new List(1);
        System.out.printf("Length is %d\n", L.data.length);

        System.out.println("Add Test, add 2 to end");
        L.add(2);
        System.out.printf("The list is %d %d\n", L.get(0), L.get(1));
        System.out.printf("Length is %d\n", L.size());

        System.out.println("Delete Test, delete last element");
        L.remove(1);
        System.out.printf("First element is %s\n", L.get(0));
        System.out.printf("Length is %d\n", L.size());

        System.out.println("Insert Test, Add 2 to beginning");
        L.add(2, 0);
        System.out.printf("The list is %d %d\n", L.get(0), L.get(1));
        System.out.printf("Length is %d\n", L.size());

        System.out.println("Get Test, Finished Successfully during precious tests");
        System.out.println("Size Test, Finished Successfully during precious tests");

        System.out.println("Search Test, make list 1 2 3 4 5, find index of 3");
        L.remove(0);
        L.add(2);
        L.add(3);
        L.add(4);
        L.add(5);
        System.out.printf("Index of 3 is %d\n", L.IndexOf(3));

        System.out.println("Contains test, first check of 4 in list, second - check of 9\n");
        System.out.printf("3 in list is %b, 9 in list is %b\n", L.contains(4), L.contains(9));

        System.out.println("Setter test, the fifth element shall be 100");
        L.set(100,4);
        System.out.printf("The fifth element is %d\n", L.get(4));

        System.out.println("IsEmpty test");
        System.out.printf("List is %d %d %d %d %d\n", L.get(0), L.get(1), L.get(2), L.get(3), L.get(4));
        System.out.printf("List is empty is %b\n", L.IsEmpty());
        System.out.println("Now we delete all data");
        L.remove(0);
        L.remove(0);
        L.remove(0);
        L.remove(0);
        L.remove(0);
        System.out.printf("List is empty is %b\n", L.IsEmpty());
    }

    public static void main(String[] args) {
        TestList();
    }
}
